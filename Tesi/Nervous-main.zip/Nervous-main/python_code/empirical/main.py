from empirical import CoCoS
if __name__ == '__main__':
    CoCoS("./try", maxProp=7, write_to_file=False)